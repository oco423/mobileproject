//
//  ViewController.h
//  FirstView5
//
//  Created by Jeffrey Lawrence Conway on 2017-03-31.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface ViewController : UIViewController{
    int timeTick;
    int minutes;
    NSTimer *timer;
}


@property float maxRecoredSpeed;
@property (strong, nonatomic) CMPedometer *pedometer;
@property (strong, nonatomic) IBOutlet UILabel *stepsTaken;
@property (strong, nonatomic) IBOutlet UILabel *distanceTraveled;
@property (strong, nonatomic) IBOutlet UILabel *stepsPerSecond;
@property (strong, nonatomic) IBOutlet UILabel *currentSpeed;
@property (strong, nonatomic) IBOutlet UILabel *maxSpeed;
@property (strong, nonatomic) IBOutlet UILabel *averageSpeed;
@property (strong, nonatomic) IBOutlet UILabel *sessionSeconds;
@property (strong, nonatomic) IBOutlet UILabel *sessionMinutes;

@end


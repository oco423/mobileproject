//
//  ViewController.h
//  FirstView5
//
//  Created by Jeffrey Lawrence Conway on 2017-03-31.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>
#import <CoreLocation/CoreLocation.h>

@interface ViewController : UIViewController{
    NSNumber *maxRecordedSpeed;
}

@property (strong, nonatomic) CMPedometer *pedometer;
@property (strong, nonatomic) CLLocationManager *locman;
@property (strong, nonatomic) IBOutlet UILabel *stepsTaken;
@property (strong, nonatomic) IBOutlet UILabel *distanceTraveled;
@property (strong, nonatomic) IBOutlet UILabel *stepsPerSecond;
@property (strong, nonatomic) IBOutlet UILabel *currentSpeed;
@property (strong, nonatomic) IBOutlet UILabel *maxSpeed;

@end


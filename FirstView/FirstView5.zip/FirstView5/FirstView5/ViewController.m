//
//  ViewController.m
//  FirstView5
//
//  Created by Jeffrey Lawrence Conway on 2017-03-31.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.pedometer = [[CMPedometer alloc] init];
    [self.pedometer startPedometerUpdatesFromDate:[NSDate date] withHandler:^(CMPedometerData * _Nullable data, NSError *err) {
            
        [self updateData:data];
    }];
    
    self.locman = [[CLLocationManager alloc] init];
    //self.locman.delegate = self;
    self.locman.desiredAccuracy = kCLLocationAccuracyBest;
    [self.locman startUpdatingLocation];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updateData:(CMPedometerData *)data{
    NSNumberFormatter *stepFormat = [[NSNumberFormatter alloc] init];
    stepFormat.maximumFractionDigits = 0;
    
    NSNumberFormatter *distanceFormat = [[NSNumberFormatter alloc] init];
    distanceFormat.maximumFractionDigits = 2;
    
    NSNumberFormatter *stepsPerSecondFormat = [[NSNumberFormatter alloc] init];
    stepsPerSecondFormat.maximumFractionDigits = 1;
    
    if ([CMPedometer isStepCountingAvailable]) {
        self.stepsTaken.text = [stepFormat stringFromNumber:data.numberOfSteps];
    }
    else {
        self.stepsTaken.text = @"N/A";
    }
    
    if ([CMPedometer isDistanceAvailable]){
        self.distanceTraveled.text = [distanceFormat stringFromNumber:data.distance];
    }
    else {
        self.distanceTraveled.text = @"N/A";
    }
    
    if ([CMPedometer isCadenceAvailable]){
        self.stepsPerSecond.text = [stepsPerSecondFormat stringFromNumber:data.currentCadence];
    }
    else {
        self.stepsPerSecond.text = @"N/A";
    }
}

- (void) locman:(CLLocationManager *)manager didUpdateLocation:(NSArray *)locations{
    CLLocation *currentLocation = [locations lastObject];
    self.currentSpeed.text = [NSString stringWithFormat:@"%.1f", currentLocation.speed];
    if(currentLocation.speed > [maxRecordedSpeed doubleValue]){
        maxRecordedSpeed = [NSNumber numberWithDouble:currentLocation.speed];
    }
    self.maxSpeed.text = [NSString stringWithFormat:@"%.1f", [maxRecordedSpeed doubleValue]];
}


@end

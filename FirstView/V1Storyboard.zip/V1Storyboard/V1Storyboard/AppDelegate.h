//
//  AppDelegate.h
//  V1Storyboard
//
//  Created by Jeffrey Lawrence Conway on 2017-04-05.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


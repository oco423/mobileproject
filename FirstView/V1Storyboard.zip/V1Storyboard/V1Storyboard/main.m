//
//  main.m
//  V1Storyboard
//
//  Created by Jeffrey Lawrence Conway on 2017-04-05.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

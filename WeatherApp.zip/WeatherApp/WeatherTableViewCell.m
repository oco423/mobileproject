//
//  WeatherTableViewCell.m
//  WeatherApp
//
//  Created by Bradley Mark Gavan on 2016-04-04.
//  Copyright © 2016 Bradley Mark Gavan. All rights reserved.
//

#import "WeatherTableViewCell.h"

@implementation WeatherTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

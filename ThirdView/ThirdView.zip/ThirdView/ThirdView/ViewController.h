//
//  ViewController.h
//  ThirdView
//
//  Created by Jeffrey Lawrence Conway on 2017-04-04.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

#import "AppDelegate.h"

@interface ViewController : UIViewController <CLLocationManagerDelegate>{
    
    IBOutlet UIImageView *testImage;
}

@property (weak, nonatomic) IBOutlet UILabel *test;

@end


//
//  AppDelegate.h
//  ThirdView
//
//  Created by Jeffrey Lawrence Conway on 2017-04-04.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

+(void)downloadData:(NSURL *)url withCompletionHandler:(void(^)(NSData *data))completionHandler;


@end


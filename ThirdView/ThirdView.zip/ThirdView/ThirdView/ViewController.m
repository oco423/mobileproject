//
//  ViewController.m
//  ThirdView
//
//  Created by Jeffrey Lawrence Conway on 2017-04-04.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSString *APIKey;
}

@end

@implementation ViewController {
    
    CLLocationManager *locationManager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    APIKey = @"9ee3e4133c207d8258520dbdff88ec66";
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager requestWhenInUseAuthorization];
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"Location could not be found");
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    CLLocation *currentLocation = [locations lastObject];
    
    if (currentLocation != nil) {
        NSString *lon = [NSString stringWithFormat:@"%.6f", currentLocation.coordinate.longitude];
        NSString *lat = [NSString stringWithFormat:@"%.6f", currentLocation.coordinate.latitude];
        
        
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error){
            if (error) {
                NSLog(@"Error getting city");
            } else {
                //St. John's coordinates:
                //NSString *tempLat = @"47.574278";
                //NSString *tempLong = @"-52.735317";
                
                [self getWeatherAtLocation:lat Lon:lon];
            }
        }];
    }
}

- (void)getWeatherAtLocation:(NSString *)lat Lon:(NSString *)lon{
    NSString *apiCall = @"http://api.openweathermap.org/data/2.5/weather?lat=";
    apiCall = [apiCall stringByAppendingString:lat];
    apiCall = [apiCall stringByAppendingString:@"&lon="];
    apiCall = [apiCall stringByAppendingString:lon];
    apiCall = [apiCall stringByAppendingString:@"&units=metric&appid="];
    apiCall = [apiCall stringByAppendingString:APIKey];
    NSURL *url = [NSURL URLWithString:apiCall];
    [self getDataFromURL:url];
}

-(void)getDataFromURL:(NSURL *)url {
    [AppDelegate downloadData:url withCompletionHandler:^(NSData *data) {
        NSError *err;
        NSMutableDictionary *returnedDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&err];
        if(err != nil){
            NSLog(@"Error creating dictionary");
        }
        else{
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"humidity"] floatValue]];         //humidity
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"pressure"] floatValue]];         //presure
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp"] floatValue]];             //temperature
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp_max"] floatValue]];         //max temperature
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp_min"] floatValue]];         //min temperature
            self.test.text = [NSString stringWithFormat:@"%.f", [returnedDict[@"raind"][@"3h"] floatValue]];                //rain for next 3 hours
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"wind"][@"speed"] floatValue]];            //wind speed
            self.test.text = [NSString stringWithFormat:@"%.f", [returnedDict[@"wind"][@"deg"] floatValue]];                //wind direction
            self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"clouds"][@"all"] floatValue]];            //percent of clouds
            testImage.image= [UIImage imageNamed:returnedDict[@"weather"][0][@"icon"]];                                     //current weather ion
            //[UIView animateWithDuration:5 animations:^{
            // testImage.frame = CGRectMake(133.0f, 140.0f, testImage.frame.size.width, testImage.frame.size.height);
            //}];
        }
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  ViewController.m
//  ThirdView
//
//  Created by Jeffrey Lawrence Conway on 2017-04-04.
//  Copyright © 2017 Jeffrey Lawrence Conway. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NSString *APIKey;
}

@end

@implementation ViewController {
    
    CLLocationManager *locationManager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    APIKey = @"9ee3e4133c207d8258520dbdff88ec66";
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    [locationManager requestWhenInUseAuthorization];
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    [locationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"Location could not be found");
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    CLLocation *currentLocation = [locations lastObject];
    
    if (currentLocation != nil) {
        NSString *lon = [NSString stringWithFormat:@"%.6f", currentLocation.coordinate.longitude];
        NSString *lat = [NSString stringWithFormat:@"%.6f", currentLocation.coordinate.latitude];
        
        
        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
        [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error){
            if (error) {
                NSLog(@"Error getting city");
            } else {
                //NSString *tempLat = @"47.574278";
                //NSString *tempLong = @"-52.735317";
                
                [self getWeather:lat Lon:lon];
            }
        }];
    }
}

- (void)getWeather:(NSString *)lat Lon:(NSString *)lon{
    NSString *apiCall = @"http://api.openweathermap.org/data/2.5/weather?lat=";
    apiCall = [apiCall stringByAppendingString:lat];
    apiCall = [apiCall stringByAppendingString:@"&lon="];
    apiCall = [apiCall stringByAppendingString:lon];
    apiCall = [apiCall stringByAppendingString:@"&units=metric&appid="];
    apiCall = [apiCall stringByAppendingString:APIKey];
    NSURL *url = [NSURL URLWithString:apiCall];
    [self getDataFromURL:url];
}

-(void)getDataFromURL:(NSURL *)url {
    [AppDelegate downloadData:url withCompletionHandler:^(NSData *data) {
        NSError *err;
        NSMutableDictionary *returnedDict = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&err];
        if(err != nil){
            NSLog(@"Error creating dictionary");
        }
        self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"humidity"] floatValue]];
        self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"pressure"] floatValue]];
        self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp"] floatValue]];
        self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp_max"] floatValue]];
        self.test.text = [NSString stringWithFormat:@"%.01f", [returnedDict[@"main"][@"temp_min"] floatValue]];
        testImage.image= [UIImage imageNamed:returnedDict[@"weather"][0][@"icon"]];
        [UIView animateWithDuration:3.0f animations:^{
            testImage.frame = CGRectMake(133.0f, 140.0f, testImage.frame.size.width, testImage.frame.size.height);
        }];
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

//
//  SecondViewController.h
//  Commute Buddy
//
//  Created by Samuel Ash on 2017-03-22.
//  Copyright © 2017 Samuel Ash. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController


@end

